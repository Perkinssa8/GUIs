const links = document.getElementsByClassName('quicklinks');
console.log(links);

